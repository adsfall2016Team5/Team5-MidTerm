
#------------------Weather data-------------#


install.packages("RCurl")
install.packages("RJSONIO")
install.packages("XML")
install.packages("zoo")
library(zoo)
library(RCurl)
library(RJSONIO)
library(plyr)
library(XML)

#This is the function to retrieve the geolocation from the address
url <- function(address, return.call = "json", sensor = "false") {
        root <- "http://maps.google.com/maps/api/geocode/"
        u <- paste(root, return.call, "?address=", address, "&sensor=", sensor, sep = "")
        return(URLencode(u))
}
geoCode <- function(address,verbose=FALSE) {
        if(verbose) cat(address,"\n")
        u <- url(address)
        doc <- getURL(u)
        x <- fromJSON(doc,simplify = FALSE)
        if(x$status=="OK") {
                lat <- x$results[[1]]$geometry$location$lat
                lng <- x$results[[1]]$geometry$location$lng
                location_type  <- x$results[[1]]$geometry$location_type
                formatted_address  <- x$results[[1]]$formatted_address
                return(c(lat, lng, location_type, formatted_address))
                Sys.sleep(1)
        } else {
                return(c(NA,NA,NA, NA))
        }
}
#End of geolocation function

#Read the csv
findata <- read.csv("Finland_addresses_area.csv",stringsAsFactors = FALSE)

#Fetch the geolocation data for the given addresses using the above function
i =1
addresses1 = NULL
while(i <= 10)
{
        #if(i %% 9 == 0) Sys.sleep(3)
        addresses1 = c(addresses1,findata[i,2])
        i = i+1
}
locations1  <- ldply(addresses1, function(x) geoCode(x))
addresses2 = NULL
while(i > 10 && i<=20)
{
        #if(i %% 9 == 0) Sys.sleep(3)
        addresses2 = c(addresses2,findata[i,2])
        i = i+1
}
locations2  <- ldply(addresses2, function(x) geoCode(x))
addresses3 = NULL
while(i > 20 && i<=30)
{
        #if(i %% 9 == 0) Sys.sleep(3)
        addresses3 = c(addresses3,findata[i,2])
        i = i+1
}
locations3  <- ldply(addresses3, function(x) geoCode(x))
addresses4 = NULL
while(i > 30 && i<=33)
{
        #if(i %% 9 == 0) Sys.sleep(3)
        addresses4 = c(addresses4,findata[i,2])
        i = i+1
}
locations4  <- ldply(addresses4, function(x) geoCode(x))
locations=NULL
locations <- rbind(locations1,locations2,locations3,locations4)
names(locations)  <- c("lat","lon","location_type", "formatted")
#Geolocation data retrieved for all the specified addresses

#Merge the csv data with the geolocation data
totaldata = cbind(findata,locations)
#Convert the latitude and longitude values to numeric data
totaldata$lat <- as.numeric(totaldata$lat)
totaldata$lon <- as.numeric(totaldata$lon)

#Code to get the nearest airport for each Building
i <- 1
lat <- NULL
lon <- NULL
xml.url1 <- data.frame(NULL,stringsAsFactors = FALSE)
xml.url <- data.frame(NULL,stringsAsFactors = FALSE)
locdata <- data.frame(NULL,stringsAsFactors = FALSE)
locdata.t <- data.frame(NULL,stringsAsFactors = FALSE) 

#function to calculate the minimum geolocation distance
earth.dist <- function (long1, lat1, long2, lat2)
{
        rad <- pi/180
        a1 <- lat1 * rad
        a2 <- long1 * rad
        b1 <- lat2 * rad
        b2 <- long2 * rad
        dlon <- b2 - a2
        dlat <- b1 - a1
        a <- (sin(dlat/2))^2 + cos(a1) * cos(b1) * (sin(dlon/2))^2
        c <- 2 * atan2(sqrt(a), sqrt(1 - a))
        R <- 6378.145
        d <- R * c
        return(d)
}
airport <- c("")
airportlat <- c("")
airportlon <- c("")
airportdata <- data.frame(airport,airportlat,airportlon,stringsAsFactors = FALSE)
while(i <= nrow(totaldata))
{
        lat <- totaldata$lat[i]
        lon <- totaldata$lon[i]
        
        xml.url1[i,1] <- paste("http://api.wunderground.com/auto/wui/geo/GeoLookupXML/index.xml?query=",lat,sep = "")
        xml.url[i,1] <- paste(xml.url1[i,1],lon,sep=",")
        xmlfile <- xmlParse(xml.url[i,1])
        xmltop = xmlRoot(xmlfile)
        xmlfileresult <- t(xmlSApply(xmltop[["nearby_weather_stations"]][["airport"]], xmlValue))
        nodes <- getNodeSet(xmltop,"//airport/station")
        locdata<- as.data.frame(lapply(nodes, function(x) xmlSApply(x, xmlValue)),stringsAsFactors = FALSE)
        locdata.t <- t(locdata)
        locdata.t <- data.frame(locdata.t,stringsAsFactors = FALSE)
        locdata.t <- locdata.t[!locdata.t$icao=="",]
        locdata.t$lat <- as.numeric(locdata.t$lat)
        locdata.t$lon <- as.numeric(locdata.t$lon)
        nearest <- locdata.t[which.min(earth.dist(lon,lat,locdata.t$lon,locdata.t$lat)),]
        nearest <- nearest[,c(4:6)]
        names(nearest) <- c("airport","airportlat","airportlon")
        airportdata <- rbind(airportdata,nearest)
        i <- i+1
}
airportdata <- airportdata[-1,]

#merge the nearest airport data with the building data
buildingairport <- cbind(totaldata,airportdata)
write.csv(buildingairport,"building_airport.csv")
###########################################################################################################
#***********************************************************************************************************

#Fetch weather data for the airports
install.packages("weatherData")
library(weatherData)
install.packages("dplyr")
library(dplyr)
install.packages("zoo")
library(zoo)

Date<-as.data.frame(seq(as.Date("2013/1/1"), as.Date("2013/12/31"),by = "days"))
Date<-as.data.frame(Date[rep(row.names(Date),times=24),])
names(Date)<-c("Date")
Date<-as.data.frame(Date[order(as.Date(Date$Date, format="%Y/%m/%d")),])
names(Date)<-c("Date")
Hour<-as.data.frame(c(rep(0:23,times=365)))
names(Hour)<-c("Hour")
df1<-cbind(Date,Hour)

#etch unique values for the airports in the Bilding data
airports <- data.frame(unique(airportdata$airport),stringsAsFactors = FALSE)
datalist = list()

#Retrive weather data for each airport
i=1
while(i <= nrow(airports))
{
        d3<- getWeatherForDate(airports[i,1], start_date="2013-01-01",
                               end_date = "2013-12-31",
                               opt_detailed = TRUE,opt_custom_columns = T,
                               custom_columns=c(1,2,3,4,5,6,7,8,9,10,11,12,13))
        #head(d3)  
        dates <- format(as.POSIXct(strptime(d3$Time,"%Y-%m-%d %H:%M:%S",tz="")) ,format = "%m/%d/%Y")
        hours <- format(as.POSIXct(strptime(d3$Time,"%Y-%m-%d %H:%M:%S",tz="")) ,format = "%H")
        d3$Date <- dates
        d3$Date<- as.Date(d3$Date,format = "%m/%d/%Y")
        d3$Hour <- as.numeric(hours)
        d3$Humidity <- as.numeric(d3$Humidity) #NAs introduced
        d3$Wind_SpeedMPH <- as.numeric(d3$Wind_SpeedMPH) #NAs introduced
        # replace all NAs with the previous value
        na.locf(d3$Wind_SpeedMPH)
        d3 <- d3[,-c(1,2)]
        d3 = d3 %>% group_by(Date,Hour) %>% summarize(TemperatureF=mean(TemperatureF),
                                                      Dew_PointF=mean(Dew_PointF),
                                                      Humidity=mean(Humidity),
                                                      Sea_Level_PressureIn = mean(Sea_Level_PressureIn),
                                                      VisibilityMPH = mean(VisibilityMPH),
                                                      Wind_SpeedMPH = mean(Wind_SpeedMPH),
                                                      WindDirDegrees = mean(WindDirDegrees),
                                                      Conditions = max(Conditions),
                                                      Wind_Direction = max(Wind_Direction),
                                                      Gust_SpeedMPH = max(Gust_SpeedMPH),
                                                      PrecipitationIn = max(PrecipitationIn),
                                                      Events = max(Events))
        
        d3 <- merge(df1,d3,by=c("Date","Hour"),all.x = TRUE)
        d3$Airport <- airports[i,1]
        
        d3$TemperatureF <- na.locf(d3$TemperatureF)
        d3$Dew_PointF <- na.locf(d3$Dew_PointF)
        d3$Humidity <- na.locf(d3$Humidity)
        d3$Sea_Level_PressureIn <- na.locf(d3$Sea_Level_PressureIn)
        d3$VisibilityMPH <- na.locf(d3$VisibilityMPH)
        d3$Wind_SpeedMPH <- na.locf(d3$Wind_SpeedMPH)
        d3$WindDirDegrees <- na.locf(d3$WindDirDegrees)
        d3$Conditions <- na.locf(d3$Conditions)
        d3$Wind_Direction <- na.locf(d3$Wind_Direction)
        d3$Gust_SpeedMPH <- na.locf(d3$Gust_SpeedMPH)
        d3$PrecipitationIn <- na.locf(d3$PrecipitationIn)
        d3$Events <- na.locf(d3$Events)
        
        datalist[[i]] <- d3
        
        i <- i+1
}
#merge weather data for all unique airports corresponding to the building data
big_data = do.call(rbind, datalist)
write.csv(big_data,"complete_weather_data.csv")
#merge building data with weather data
tempfinal <- merge(buildingairport,big_data,by.x="airport",by.y="Airport",all.y=TRUE)
write.csv(tempfinal,"TempFinal.csv")
