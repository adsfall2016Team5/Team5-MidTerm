install.packages("chron")
install.packages("timeDate")
library(timeDate)

library(chron)
library(plyr)
library(dplyr)

data <- read.csv("Finland_masked.csv",header = TRUE,stringsAsFactors = FALSE)
address <- read.csv("Finland_addresses_area.csv",header = TRUE,stringsAsFactors = FALSE)
datatemp <- data

datatemp1=datatemp %>% group_by(vac,type) %>% filter(type=="elect" | type =="Dist_Heating")
elect=datatemp1%>% filter(type=="elect" )
unique(x = elect$BuildingID)
heat=datatemp1%>% filter(type=="Dist_Heating" )
unique(x = heat$BuildingID)
unique(x = datatemp1$type=="elect")
datatemp1$vac[datatemp1$BuildingID== 81909] <- "Building 27"
datatemp1$vac[datatemp1$BuildingID== 82254] <- "Building 9"
datatemp1$vac[datatemp1$BuildingID== 83427] <- "Building 9"
datatemp1$vac[datatemp1$BuildingID== 84681] <- "Building 9"

datatemp2 <- transform(datatemp1,uniquekey=paste0(datatemp1$BuildingID,datatemp1$meternumb))
datatemp2 <- plyr::rename(datatemp2, c("vac"="building"))


datatemp3 <- merge(x = datatemp2, y = address, by = "building", all.x = TRUE)
datatemp3$Consumption_per_squaremeter <- (datatemp3$Consumption/datatemp3$area_floor._m.sqr)


tempdate <- datatemp3[,5]


tempdate2 <- as.Date(as.character(tempdate), "%Y%m%d")

# fetching details from date column
datemonth <- format(tempdate2,"%m")
dateyear <- format(tempdate2,"%Y")
dateday <- format(tempdate2,"%d")



dayofweek <- weekdays(tempdate2)


ifweekend <- is.weekend(tempdate2)


holiday <-  as.data.frame(is.holiday(tempdate2,2013-05-01))
datedata <- data.frame("Date"=tempdate2,"Month"=datemonth,"Day"=dateday,"Year"=dateyear,"Day of Week"=dayofweek,"Weekend"=ifweekend)

datatemp4 <- cbind(datatemp3,datedata)
datatemp4$Base_hour_Flag <- ifelse((datatemp3$hour==0) |(datatemp3$hour==1) |(datatemp3$hour==2) |(datatemp3$hour==3) |(datatemp3$hour==4)|(datatemp3$hour==22)|(datatemp3$hour==23), "True", "False")
datatemp4$Base_hour_Flag <- as.logical(datatemp4$Base_hour_Flag)
class(datatemp4$Base_hour_Flag)

datatemp4$Holiday <- ifelse((datatemp4$date==20130101) |(datatemp4$date==20130106) |(datatemp4$date==20130329) |(datatemp4$date==20130331) |(datatemp4$date==20130401) |(datatemp4$date==20130501) |(datatemp4$date==20130509) |(datatemp4$date==20130512) |(datatemp4$date==20130519) |(datatemp4$date==20130621) |(datatemp4$date==20130622) |(datatemp4$date==20131102) |(datatemp4$date==20131110) |(datatemp4$date==20131206) |(datatemp4$date==20131224) |(datatemp4$date==20131225) |(datatemp4$date==20131226) ,"True","False")
unique(x = datatemp2$uniquekey)

daily_base_hr_usage_dataset <-datatemp4 %>% filter(datatemp4$Base_hour_Flag=="TRUE") 


daily_base_hr_usage_dataset <-as.data.frame(daily_base_hr_usage_dataset %>% group_by(BuildingID,type,meternumb,Weekend,Month,Holiday)%>%summarize(Base_hr_usage=mean(Consumption_per_squaremeter)))



datatemp5 <- merge(x = datatemp4, y = daily_base_hr_usage_dataset, by = c("BuildingID","type","meternumb","Weekend","Month","Holiday"), all.x = TRUE)

datatemp5$Base_Hour_Class <- ifelse(datatemp5$Consumption_per_squaremeter>datatemp5$Base_hr_usage,"High","Low")
datatemp5$Base_Hour_Class <- as.vector(datatemp5$Base_Hour_Class)
class(daily_base_hr_usage_dataset)
write.csv(datatemp5,file="Midterm_version2.csv")
datatemp5 <- plyr::rename(datatemp5, c("hour"="Hour"))
datatemp5 <- plyr::rename(datatemp5, c("X..address"="Address"))


MyData <- read.csv(file="TempFinal.csv", header=TRUE, sep=",")
MyData <- plyr::rename(MyData, c("X..address"="Address"))
datatemp6 <- merge(x = datatemp5, y = MyData, by = c("building","Date","Hour","Address"), all.x = TRUE)
write.csv(datatemp6,file="Midterm_version3.csv")


